Fallout34 한국어판 — xTranslator XML 번역 가져오기
=============================================
1. xTranslator를 Fallout 4 게임 모드로 실행하세요.
2. XML의 Addon과 같은 이름의 Fallout34.esm 또는 FalloutNV34.esm을 엽니다.
3. 파일(File) -> 번역 가져오기(Import Translation) -> XML 파일로
   해당 게임의 *_en_ko.xml을 하나씩 불러옵니다.
4. 가급적 레코드/FormID 참조 기반으로 가져오고, 적용 미리보기를 검사하세요.
   영어가 동일하다는 이유로 모든 문구를 무조건 덮어쓰면 안 됩니다.
5. *_CONTEXT_REVIEW.xml은 같은 영문에 서로 다른 검증 번역이 존재하는
   특수 항목입니다. 일괄 가져오지 말고 레코드별로 수동 확인하세요.
   같은 이름의 *_CONTEXT_REVIEW.tsv에서 각 FormID를 확인할 수 있습니다.
6. 이번 패키지는 번역용 XML이지 게임에 바로 설치하는 한글 ESM이 아닙니다.
   게임에 설치된 ESM/ESP/BA2 및 온라인 모드는 변경하지 않았습니다.
7. 연결 수는 정적 필드 계획이며 인게임 번역 완성을 증명하지 않습니다.
   데이터 원본은 각 *_XML_report.json의 ESM SHA256에 고정되어 있습니다.
8. 폴아웃 4 본편·DLC·CC 한국어판/폰트는 이 ZIP에 포함되지 않습니다.
   Fallout34 포팅 ESM 두 개의 한국어 사전만 수록했습니다.
