Fallout34 한국어판 — xTranslator XML 번역 가져오기
=============================================
[주의] 이 XML은 xTranslator 고유 sID를 포함하지 않습니다.
       내보낸 xTranslator 원본 XML과 달리, 텍스트 기준 대조로 처리될 수 있습니다.
       XML의 EDID/REC가 있어도 원본 레코드가 정확히 매칭된다는 보장은 없습니다.
       적용 전 미리보기에서 문맥/레코드를 확인하고 무조건 일괄 적용하지 마세요.
1. xTranslator를 Fallout 4 게임 모드로 실행하세요.
2. XML의 Addon과 같은 이름의 Fallout34.esm 또는 FalloutNV34.esm을 엽니다.
   FalloutNV.esm (원본 뉴베가스)에는 이 XML을 적용하면 안 됩니다.
3. 파일(File) -> 번역 가져오기(Import Translation) -> XML 파일로
   해당 게임의 *_en_ko.xml을 하나씩 불러옵니다.
4. 적용 미리보기의 원문/번역/게임 내 의미가 맞는지 확인하세요.
   이 XML만으로 레코드 ID와 문맥을 보장할 수 없기 때문에
   sID가 필요한 정확한 가져오기는 대상 ESM에서 xTranslator가 직접
   내보낸 XML 템플릿에 번역을 병합하는 별도 절차가 필요합니다.
5. *_CONTEXT_REVIEW.xml은 같은 영문에 서로 다른 검증 번역이 존재하는
   특수 항목입니다. 일괄 가져오지 말고 레코드별로 수동 확인하세요.
   같은 이름의 *_CONTEXT_REVIEW.tsv에서 각 FormID를 확인할 수 있습니다.
6. 이번 패키지는 번역용 XML이지 게임에 바로 설치하는 한글 ESM이 아닙니다.
   게임에 설치된 ESM/ESP/BA2 및 온라인 모드는 변경하지 않았습니다.
7. 연결 수는 정적 필드 계획이며 인게임 번역 완성을 증명하지 않습니다.
   데이터 원본은 각 *_XML_report.json의 ESM SHA256에 고정되어 있습니다.
8. 폴아웃 4 본편·DLC·CC 한국어판/폰트는 이 ZIP에 포함되지 않습니다.
   Fallout34 포팅 ESM 두 개의 한국어 사전만 수록했습니다.
